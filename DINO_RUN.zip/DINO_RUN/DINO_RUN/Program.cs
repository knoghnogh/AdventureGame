﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


/*
 * [DinoRun]
 * by Mohamad Noghnogh
 * July 26th 2020 
 * Assistance by Bassem Noghnogh
 */


namespace DINO_RUN
{
    class Program
    {
        static void Main(string[] args)
        {
            Game dinoGame = new Game();
            dinoGame.StartGame();
            ReadKey();
        }
    }
}
