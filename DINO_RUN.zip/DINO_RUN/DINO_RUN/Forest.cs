﻿using System;
using System.Threading;
using static System.Console;

namespace DINO_RUN
{
    class Forest : Locations
    {
        public Forest(ConsoleColor color) : base(color)
        {
            name = "Forest";
            description = "Big, wide, green, and untouched";
            dest1 = null;
            dest2 = null;
        }

        public override void LocationMenu()
        {
            WriteLine("Where will you go?");
            WriteLine("A. Leaves");
            WriteLine("B. Water");
        }
    }
}
