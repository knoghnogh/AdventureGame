﻿using System;
using System.Threading;
using static System.Console;

namespace DINO_RUN
{
    class Item
    {
        private string name;
        private string description;

        public Item(string name, string descr)
        {
            this.name = name;
            description = descr;
        }

        public string Info()
        {
            string info = name + ": " + description;
            return info;
        }
    }
}
