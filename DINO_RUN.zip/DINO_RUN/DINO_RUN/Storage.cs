﻿using System;
using System.Threading;
using static System.Console;

namespace DINO_RUN
{
    class Storage : Locations
    {
        public Storage(ConsoleColor color) : base(color)
        {
            name = "Storage";
            description = "Room that has items that will aid you";
            dest1 = new Start(0);
            dest2 = new Start(0);
        }

        public override void LocationMenu()
        {
            WriteLine("Which will you choose?");
            WriteLine("A. Food");
            WriteLine("B. Weapons");
        }
    }
}
