﻿using System;
using System.Threading;
using static System.Console;
using System.Collections.Generic;

namespace DINO_RUN
{
    class Dino
    {
        public string name;
        public List<Item> inventory; 
        public Locations currentLocation;

        public Dino(string name)
        {
            this.name = name;
            inventory = new List<Item>();
            currentLocation = new Start();

        }
    }
}